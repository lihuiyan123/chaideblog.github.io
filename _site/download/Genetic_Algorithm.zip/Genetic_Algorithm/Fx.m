function fx = Fx(pop)
fx = pop.*sin(3*pi*pop);