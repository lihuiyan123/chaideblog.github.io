function fitness = Fitness(pop)
for n = 1:size(pop,2)
    fitness(n) = 1/abs(Fx(pop(n))-1.836394128656826);
end
%1.83940
%1.836394128656826