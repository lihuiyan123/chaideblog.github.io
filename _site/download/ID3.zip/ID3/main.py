import myTools

import myClass

import id3

import printTree

attrName = ['outlook', 'temperature', 'humidity', 'windy']
data = myTools.getDataFromFile('weather.txt', attrName)
attr = myTools.getAllAttrValue(data, attrName)
#iris = myTools.getDataFromFile('./Iris/iris.data.txt')

node = id3.id3(data, attr)

node.printAll()
for child in node.childNode.values():
	child.printAll()
	for childchild in child.childNode.values():
		childchild.printAll()

#print(str(a.serialNum) + ': attribute = ' + str(a.attribute) + '; childNode = ' + str(a.childNode))

printTree.printAll(node, [0, 0], 100)